describe('template spec', () => {
  Cypress.on( 'uncaught:exception', ( err, runnable ) =>
        // returning false here prevents Cypress from
        // failing the test
        false )

    it.only('visits the webpage, verifies if logo is present, scrolls down to the footer,counts the number of links present, captures and Visits all URLs and verifies if the urls are redirected to the correct page and Stores Captured Index', () => {
    const links = []; // Create an array to store the link URLs
    let capturedIndex; // Declare a variable to store the captured index
    const uniqueStrings = [];
      cy.visit("https://www.orangehrm.com/")
      cy.get('.container-fluid').find('img').should('have.attr', 'src').should('include','OrangeHRM_Logo.svg')
      cy.get('.homepage-product-section-list').eq(0).scrollIntoView()
      cy.get('.homepage-product-section-list ul') 
        .find('a') // Find the links within the list
        .should('exist') // Ensure that the links exist
        .then((links) => {
          const linkCount = links.length;
          cy.log(`Total links within the list in the footer: ${linkCount}`)
            cy.get('.homepage-product-section-list ul') 
              .find('a')// Find the <a> elements within the parent element
                .each((links, index, linksArray) => {
                    // Use '.invoke()' to get the 'href' attribute of each link and store it in the 'links' array
                    cy.wrap(links).invoke('attr', 'href').then((href) => {
                      if (href) {
                          // Ensure that the 'href' is not empty before adding it to the 'links' array
                            //links.push(href);

                            const uniqueString = href.split('/').slice(-3).join('/');
                            //uniqueStrings.push(uniqueString);
          
                            //Visit the URL corresponding to the href
                            //Verifies if the url includes a specific string to assert that the url is working
                            //and redirecting to the expected webpage
                            cy.visit(href);
                            cy.url().should('include', uniqueString);  
                                                      
                            // Store the current index in the 'capturedIndex' variable
                            capturedIndex = index;

                            cy.log(`Captured Href ${index + 1}: ${href}`);
                            cy.log(`Unique String ${index + 1}: ${uniqueString}`);
                            // Check if all links have been iterated
                                if (index === linksArray.length - 1) {
                                // All links have been iterated, exit the test
                                    cy.log('All hrefs have been visited and index captured.');
                                  }
                       }
                    });
                })
              .then(() => {
                  // Use the 'capturedIndex' variable for any further actions or assertions if needed
                      if (capturedIndex !== undefined) {
                          cy.log(`Captured Index: ${capturedIndex}`);
                          }
                       });
                });
  })
})
